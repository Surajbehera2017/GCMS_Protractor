
var ExpandableToggle = require('../../../../display/legis/sections/expandable-toggle.po.js');
var LegislationAuthorNoteSection = function () {

    this.expandable = new ExpandableToggle('collapsed-author-notes-link','non-collapsed-author-notes-link');

    this.edition = {};
};
LegislationAuthorNoteSection.prototype = Object.create({}, {
   // _editorialview:{get: function () { return element(by.css('[ng-click="authorNotesSumData.viewAuThorNotesDetailAll()"]'))}},
    
      _editorialview:{get: function () { return element(by.css('div #authorNotesViewAllLink strong.ng-binding'))}},
    _authorTableContainer:{get: function () { return element(by.css('#authorTableContainer'))}},

    _deletenote:{get: function (){return element(by.css('[ng-click="deleteAuthorNote($item.id)"]'))}},
    _yesbutton:{get: function (){return  element(by.css('.btn.btn-primary.pull-right.ng-scope.ng-binding'))}},
    _closeTable:{get: function (){return element(by.css('[ng-click="close()"]'))}},
   //_fristcheckboxnote:{get: function (){return element.all(by.css('input[ng-model="$item.selected"]'))}},
    _fristcheckboxnote:{get: function (){return element.all(by.css('[name="R0_C0"]>div>input'))}},
    
   // _topdeletebutton:{get: function (){return element(by.css('#headerTableAuthorNote li:nth-child(3) a'))}},
    _topdeletebutton:{get: function (){return element.all(by.css('a[ng-click="deleteAuthorNote($item.id)"]')).get(0)}},
    _first: {get: function () { return element(by.css('button[ng-click^="first()"]')); }},
    _previous: {get: function () { return element(by.css('button[ng-click^="previous()"]')); }},
    _next: {get: function () { return element(by.css('button[ng-click^="next()"]')); }},
    _last: {get: function () { return element(by.css('button[ng-click^="last()"]')); }},

    _scrollTo: {
        value: function (webelement) {
            // There are some issues with the double scroll when trying to click some elements
            browser.executeScript(function (element) { element.scrollIntoView(false);}, webelement.getWebElement());
        }
    },

	 _selectItem:{get: function () {return element(by.model('$item.selected'));}},
    

    clickSelectedItem:{
		get: function () {
			return this._selectItem.click();
		}
	},
	
    haseditorialview: {
        get: function () {
            this._scrollTo(this._editorialview);
            return this._editorialview.isDisplayed();
        }
    },
    getTextviewall:{
        get: function (){
            this._scrollTo(this._editorialview);
            return this._editorialview.getText();
        }
    },
    clickeditorialview: {
        get: function () {
            this._scrollTo(this._editorialview);
            return this._editorialview.click();
        }
    },
    hasauthorTableContainer: {
        get: function () {
              //this._scrollTo(this._authorTableContainer);
            return this._authorTableContainer.isDisplayed();
        }
    },
    clickdeletenote: {
        get: function () {
            return this._deletenote.click();
        }
    },
    clickyesbutton: {
        get: function () {
            return this._yesbutton.click();
        }
    },
    clickFirst: {
        get: function () {
            this._scrollTo(this._first);
            return this._first.click();
        }
    },
    clickPrevious: {
        get: function () {
            this._scrollTo(this._previous);
            return this._previous.click();
        }
    },

    clickNext: {
        get: function () {
            this._scrollTo(this._next);
            return this._next.click();
        }
    },

    clickLast: {
        get: function () {
            this._scrollTo(this._last);
            return this._last.click();
        }
    },
    clickcloseTable:{
        get: function (){
            return this._closeTable.click();
        }
    },
    clickFristCheckbox: {
        get: function () {
            // From the element list, get the fist one
            var notecheckbox = this._fristcheckboxnote.first();
            // Call the inherited method.
            //this._scrollTo(notecheckbox);
            // Perform the relevant action for the test
            return notecheckbox.click();
        }
    },
    clickonTapdeleteButton:{
        get: function (){
            return this._topdeletebutton.click().click();
        }
    }
});
module.exports = LegislationAuthorNoteSection;